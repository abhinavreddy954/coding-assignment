let add=document.getElementById("add");
let task=document.getElementById("task");
let show=document.getElementById("show");
let count=1;
let s=new Array(count);

add.addEventListener("click",()=>{
    let taskToAdd=task.value;
    console.log(taskToAdd);
    if(taskToAdd!=null && taskToAdd!=""){
        s.push(taskToAdd);
        count++;
    }
    add.style.backgroundColor="white";
    task.value="";
})

let display=document.getElementById("display");
let dcount=0;
display.addEventListener("click",()=>{
   while(dcount<s.length){
    let t=s[dcount];
        if(t!=undefined){

            let div=document.createElement("div");
            div.setAttribute("id","contents")
            let p=document.createElement("p");
            let ptext=document.createTextNode(t);
            let pid=p.setAttribute("id",`p${dcount}`);
            p.appendChild(ptext);

            let btnremove=document.createElement("button");
            let btn=document.createTextNode("remove");
            let btnid=btnremove.setAttribute("id",`btn${dcount}`);
            btnremove.setAttribute("value",dcount);
            // let btnonClick=btnremove.setAttribute("onclick",`{ ${show.removeChild[btnremove.value]}};`);
            btnremove.appendChild(btn);

            console.log(show);
            div.appendChild(p);
            div.appendChild(btnremove);
            show.appendChild(div);
            console.log(s);
            // console.log(btnremove);
            // console.log(t);
            btnremove.addEventListener("click",()=>{
                delete s[btnremove.value];
                div.remove();
                btnremove.style.backgroundColor="white";
                add.style.backgroundColor="#f0f0f0";
                display.style.backgroundColor="#f0f0f0";
            })
        }
        dcount++;
        add.style.backgroundColor="#f0f0f0";
        display.style.backgroundColor="white";
    }
})


// let remove=document.getElementsByTagName("button");
// remove.addEventListener("click",()=>{

// })
