let ar=["https://wallpaperbat.com/img/410979-hd-wallpaper-top-free-1900-x-1200-hd-background.jpg","https://wallpapercave.com/wp/wp2599594.jpg","https://wallpapercave.com/wp/wp2599601.jpg","https://wallpaperbat.com/img/44154-hd-wallpaper.jpg","https://wallpaperbat.com/img/427401-download-wallpaper-1900x1200-smoke-multi-colored-lines-patterns.jpg"]
let img=document.getElementById("img");
let prev=document.getElementById("prev");
let next=document.getElementById("next");
let count=0;

img.src=ar[0];
prev.addEventListener("click",()=>{
    if(count!=0){
        --count;
        console.log(count);
        img.src=ar[count];
    }
})

next.addEventListener("click",()=>{
    if(count < ar.length-1){
        ++count;
        console.log(count);
        img.src=ar[count];
    }
})